 -- Find the market segment type that generates the highest average price per room
select market_segment_type, round(avg(avg_price_per_room),2) as AvgPricePerRoom
from hostel
group by market_segment_type
order by AvgPricePerRoom desc limit 1;