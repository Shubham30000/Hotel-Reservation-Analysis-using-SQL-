-- Which meal plan is the most popular among guests?
select type_of_meal_plan, count(*) as Count from hostel
group by type_of_meal_plan
order by Count desc limit 1;