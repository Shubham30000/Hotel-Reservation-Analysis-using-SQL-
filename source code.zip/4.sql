-- How many reservations were made for the year 20XX (replace XX with the desired year)?
select extract(year from arrival_date) as year, count(*) as total_reservations
from hostel
where extract(year from arrival_date) = 2018
group by year;