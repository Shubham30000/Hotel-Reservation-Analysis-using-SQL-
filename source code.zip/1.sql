-- What is the total number of reservations in the dataset
select count(*) from hostel