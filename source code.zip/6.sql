-- How many reservations fall on a weekend (no_of_weekend_nights > 0)?
select count(*) as total_reservations
from hostel
where no_of_weekend_nights > 0;