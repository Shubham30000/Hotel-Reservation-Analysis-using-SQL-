-- What is the average number of nights (both weekend and weekday) spent by guests for each room 
--  type? 
select room_type_reserved, round(avg(no_of_weekend_nights + no_of_week_nights),2) as AvgNights
from hostel 
group by room_type_reserved
order by room_type_reserved;