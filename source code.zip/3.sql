-- What is the average price per room for reservations involving children?
select avg(avg_price_per_room) as avg_price_per_room
from hostel 
where no_of_children > 0 ;