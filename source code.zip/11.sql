--  What is the average number of weekend nights for reservations involving children?
select round(avg(no_of_weekend_nights),2) as avg_weekend_nights
from hostel
where no_of_children > 0;