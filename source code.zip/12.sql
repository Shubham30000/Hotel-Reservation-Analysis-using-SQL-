--  How many reservations were made in each month of the year?
select extract(month from arrival_date) as Month, count(*) as Reservationcount
from hostel
group by extract(month from arrival_date)
order by extract(month from arrival_date)