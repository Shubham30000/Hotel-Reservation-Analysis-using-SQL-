-- How many reservations have a booking status of "Confirmed"
select booking_status, count(*) as confirmed_bookings
from hostel
group by booking_status
order by confirmed_bookings desc limit 1;