-- What is the most commonly booked room type?
select room_type_reserved, count(*) as count 
from hostel
group by room_type_reserved
order by count desc limit 1;