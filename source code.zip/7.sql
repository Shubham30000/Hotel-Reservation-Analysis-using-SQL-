-- What is the highest and lowest lead time for reservations?
select max(lead_time) as highest, min(lead_time) as lowest
from hostel