-- What is the most common market segment type for reservations
select market_segment_type, count(*) as most_common_market
from hostel
group by market_segment_type
order by most_common_market desc limit 1;