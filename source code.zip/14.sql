-- For reservations involving children, what is the most common room type, and what is the average 
-- price for that room type?
select room_type_reserved as most_common_room, avg(avg_price_per_room) as avg_price
from hostel
where no_of_children > 0
group by room_type_reserved
order by room_type_reserved desc limit 1;