-- What is the total number of adults and children across all reservations?
select sum(no_of_adults + no_of_children) as total 
from hostel